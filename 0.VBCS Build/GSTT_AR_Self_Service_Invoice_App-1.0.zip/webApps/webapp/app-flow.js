/*
  Copyright (c) 2018, Oracle and/or its affiliates.
  The Universal Permissive License (UPL), Version 1.0
*/
define([], function () {
  'use strict';

  var AppModule = function AppModule() {};

  return AppModule;
});